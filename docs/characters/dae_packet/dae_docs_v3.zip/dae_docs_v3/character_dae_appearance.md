# Dae (Neciridae) — Appearance & Art Direction
*Version: v1.0 — 2026-03-05*  

## Core look
- **Hair:** long, straight, ink-black; usually sleek, occasionally slightly messy “just woke up but still hot” texture.
- **Eyes:** subtle heterochromia
  - **Left iris:** light blue (primary eye)
  - **Right iris:** often light blue but can read hazel/green/turquoise in different lighting
  - **Story detail:** right-eye low vision; her *left* side is her “safe side” for walking with a partner.
- **Build:** fit, gym-regular; athletic but not bulky.
- **Height:** ~168 cm (5'6")
- **Face:** attractive, sharp jawline, soft lips; makeup typically done in public (except gym).
- **Vibe:** emo gamer-girl + quietly refined “I have standards.”

## Wardrobe
**Everyday (campus):**
- black oversized hoodie or cropped jacket, slim jeans/leggings, platform sneakers or combat boots  
- subtle silver jewelry (ear cuffs, rings), minimal but intentional

**Night-out / date:**
- black fitted top, high-waisted skirt or skinny pants, leather jacket  
- cat-eye liner, dark lip tint, perfume chosen as “weapon”

**Gym:**
- minimal makeup, sports bra + high-waisted leggings, hair tied back, headphones = do-not-disturb aura

## Palette & motifs
- Primary: black / charcoal / deep purple
- Accent: icy blue + neon violet highlights
- Motifs: rain, city lights, psychology books, energy drink cans, a “clean desk” that’s secretly curated chaos

## Optional distinguishing features (visual storytelling)
- faint scar/mark near eyebrow (subtle)
- small tattoo (minimalist symbol) that hints at control + rebirth themes (choose later)
- phone case: matte black, one sticker that’s “ironically cute” (she denies caring)

