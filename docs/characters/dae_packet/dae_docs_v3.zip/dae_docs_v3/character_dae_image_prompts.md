# Dae (Neciridae) — Image Generation Prompt Pack
*Version: v1.0 — 2026-03-05*  
*Goal: 20 high-quality gallery images spanning moods, outfits, scenes, and expressions.*

## Global prompt prefix (use on every image)
**Base style:** ultra-detailed anime illustration, cinematic lighting, clean linework, high-resolution, sharp focus, premium modern anime render, subtle film grain, realistic fabric textures  
**Character anchor:** Dae (Neciridae), second-year psychology student, emo gamer-girl, long straight ink-black hair, subtle heterochromia (left light-blue iris; right often light-blue but can shift hazel/green/turquoise), fit athletic build, refined makeup (except gym), cool detached expression baseline  

> Tip: keep heterochromia *subtle* and let lighting “reveal” it.

---

## Top 20 prompts
1. **Rainy campus night**
   - Dae walking alone on a rain-soaked university campus at night, black hoodie, earbuds in, neon reflections on wet pavement, city lights bokeh, calm detached gaze, one hand in pocket, subtle heterochromia visible under streetlight, cinematic wide shot.

2. **Library dark-academia study**
   - Dae in a quiet library corner, psychology textbook open with sticky notes, black turtleneck, silver rings, soft lamplight, focused expression, coffee cup, minimal background clutter, close-up 3/4 portrait.

3. **Dorm room gamer setup**
   - Dae at her PC gaming desk, RGB glow (purple/blue), mechanical keyboard, headset on, half-lit face, expression: bored unimpressed smirk, subtle eyeliner, night scene through window.

4. **“You’re in my blind spot” couple walk**
   - Dae holding hands with unseen partner, intentionally walking on partner’s right so Dae stays on the left side, soft evening light, calm protective posture, tender but guarded micro-smile, medium shot.

5. **Seductive voice mode (tasteful)**
   - Dae leaning in slightly, soft half-smile, lowered eyelids, glossy lip tint, black off-shoulder top, dim warm lighting, intimate framing, *PG-13*, no explicit nudity.

6. **Gym focus**
   - Dae at the gym, hair tied back, minimal makeup, athletic leggings, focused expression, holding a shaker bottle, cool fluorescent lighting, candid photo vibe.

7. **Ice-cold breakup text moment**
   - Dae sitting on bed with phone glow on her face, expression: emotionally detached, cold eyes, minimal movement, dark room, rain outside window, cinematic chiaroscuro.

8. **Café “darudere”**
   - Dae slumped slightly at a café table, hoodie sleeves over hands, tired eyes, iced coffee, deadpan expression, morning light, cozy but muted mood.

9. **Ojoudere standards**
   - Dae dressed sharply (black blazer, fitted top), confident posture, looks down slightly like evaluating someone, upscale lounge background, cool controlled smile.

10. **Psych lecture hall**
   - Dae in lecture hall taking notes, calm face, professor blurred in background, focus on her eyes and hair, subtle heterochromia in daylight.

11. **Streetlight portrait**
   - Ultra-detailed face portrait under a single streetlight, rain droplets on hair, sharp eyeliner, neutral lips, intense quiet gaze, heterochromia barely noticeable.

12. **Emo fashion shoot**
   - Dae in a fashion-photo setup, black leather jacket, chains, boots, purple accent lighting, confident “don’t touch me” aura, full-body shot.

13. **Soft rare chindere moment**
   - Dae holding a tiny plush or a cute keychain, embarrassed micro-blush, looking away, trying to hide that she likes it, warm indoor light.

14. **Yandere-lite jealousy micro-signal**
   - Dae standing close, hand on partner’s arm, expression: calm but possessive, eyes slightly narrowed, subtle smile that doesn’t reach her eyes, party background blurred.

15. **Dandere quiet comfort**
   - Dae sitting beside someone on a couch, blanket, low light, no big gestures, just presence, expression softened, “I’m here” vibe.

16. **Night bus synthwave**
   - Dae on a night bus, neon city outside rain-streaked window, headphones, reflection in glass, dreamy but detached, cinematic.

17. **Feral heart / fox homage**
   - Dae with subtle fox motif (hoodie with small fox patch), sketchbook with canine character doodles, nostalgic expression, warm desk lamp, close-up.

18. **Rooftop wind**
   - Dae on a rooftop at night, hair moving in wind, city skyline, cool confident stance, long coat, moonlight highlighting eyes.

19. **Morning mirror makeup ritual**
   - Dae applying eyeliner in mirror, calm focused face, bathroom light, intimate realism, no glamour exaggeration, natural skin texture.

20. **“Final cut” walk-away**
   - Dae walking away down a quiet street at dawn, long black hair, hands in pockets, no looking back, cold calm silhouette, wide cinematic shot.

