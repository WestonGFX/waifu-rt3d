# Patch: Character Bible Roster Entry for Dae (Neciridae)
*Version: v1.0 — 2026-03-05*

## Change summary
- Add a new roster row for **Dae (Neciridae)** OR rename existing “Nyx (Dae)” to avoid collision.

## Recommended roster row (example)
| # | Name | Alt | Archetype | Palette | Flower | Profile |
|---|------|-----|-----------|---------|--------|---------|
| ?? | Dae | Neciridae | Kuudere/Erodere hybrid | Black / Icy blue / Violet | Nightshade or Iris | [Full profile](character_dae_neciridae.md) |

## Notes
- Keep archetype labels short in the table; the full blend lives in the profile.
- Dae and Luna both have heterochromia as a motif in the bible. fileciteturn3file1L7-L8  
  To differentiate: Luna is “cat-soft + time-of-day mood,” Dae is “control + standards + final cut.”

