# Dae Integration Checklist
*Version: v1.0 — 2026-03-05*

## Where to place files
- `/docs/character/character_dae_neciridae.md`
- `/docs/character/character_dae_appearance.md`
- `/docs/character/character_dae_image_prompts.md`
- `/docs/character/character_dae_config.json`

## Naming collision warning (important)
Your current bible includes **“Nyx (Dae)”** as a roster entry. fileciteturn3file2L9-L11  
To avoid confusion:
- Option A (recommended): rename the existing “Nyx (Dae)” to **Nyx (Neciridae)** or **Nyx (Nightshade)**, and keep **Dae (Neciridae)** as this new character.
- Option B: replace “Nyx (Dae)” entirely with this Dae, and update the bible roster entry.

## Implementation steps (minimal)
1. Add `dae_neciridae_v1` to your character registry list (whatever JSON index your app uses).
2. Ensure prompt assembly uses: global system → character persona core → user prefs memory → session summary → user message. fileciteturn3file0L18-L27
3. Wire emotion hooks using valence/arousal/confidence mapping. fileciteturn3file0L50-L62
4. Test the 6 QA scenarios in `character_dae_neciridae.md`.

## “Ready for Claude Code” handoff packet
Paste this into Claude Code as your task:
- “Add new character config `dae_neciridae_v1` and implement prompt wrapper, memory targets, and emotion/tts hooks matching the character bible rules.”
- Attach the four Dae files above.

